import React, { useState, useEffect } from "react";
const LineChart = (props) => {
    
    return (
        <div id="chart">

        </div>
    );
};

export default LineChart;