import React from 'react';

const Graphs = () => {
	return <div>Graphs</div>;
};

export default Graphs;
