import React, { useEffect, useState } from 'react';
import { Map, Marker, Popup, TileLayer } from 'react-leaflet';
import { data } from '../../utils/data';
import L from 'leaflet';

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
	iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
	iconUrl: require('leaflet/dist/images/marker-icon.png'),
	shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

const Dashboard = () => {
	const position = [32.962171, -96.710217];
	const [counts, setCounts] = useState(0);
	// useEffect(() => {
	// 	getCounts()
	// }, [counts]);

	const getCounts = () => {
		if (counts !== position.length) {
			setInterval(() => {
				setCounts(counts + 1);
			}, 4000);
		}
	};

	return (
		<>
			<div>
				<Map
					style={{ height: '100vh' }}
					center={[position[0], position[1]]}
					zoom={6}
				>
					<TileLayer
						attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
						url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
					/>
					<Marker
						position={[position[0], position[1]]}
						onMouseOver={(e) => {
							e.target.openPopup();
						}}
						onMouseOut={(e) => {
							e.target.closePopup();
						}}
					>
						<Popup>
							<table>
								<tr>
									<td></td>
									<td></td>
								</tr>
							</table>
							<div className='info-container'>
								<div className='info-flag'>{data[0]['RTT (ms)']}</div>
								<div className='info-name'>
									{data[0]['Application Device CPU Utilization Total']}
								</div>
							</div>
						</Popup>
					</Marker>
				</Map>
			</div>
		</>
	);
};

export default Dashboard;
